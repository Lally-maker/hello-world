from django.apps import AppConfig


class BotAppConfig(AppConfig):
    name = 'bot_app'
